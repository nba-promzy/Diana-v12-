const fs = require("fs");
const path = require("path");
const pino = require("pino");
const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  makeCacheableSignalKeyStore,
  BufferJSON
} = require("@whiskeysockets/baileys");

const PREFIX = process.env.PREFIX || ".";
const OWNER = (process.env.OWNER_NUMBER || "").replace(/\D/g, "");
const BOT_NAME = process.env.BOT_NAME || "DIANA V12";

function decodeSession(session) {
  if (!session) return null;
  const raw = session.includes(":") ? session.slice(session.indexOf(":") + 1) : session;
  return JSON.parse(Buffer.from(raw, "base64").toString("utf8"), BufferJSON.reviver);
}

async function restoreSession(sessionId, authDir) {
  if (!sessionId) return false;
  const data = decodeSession(sessionId);
  if (!data?.files) throw new Error("Invalid SESSION_ID: missing auth files");

  fs.mkdirSync(authDir, { recursive: true });
  for (const [name, value] of Object.entries(data.files)) {
    fs.writeFileSync(path.join(authDir, name), value, "utf8");
  }
  return true;
}

async function startBot() {
  const authDir = process.env.AUTH_DIR || path.join(process.cwd(), "auth");
  if (process.env.SESSION_ID) {
    try {
      await restoreSession(process.env.SESSION_ID, authDir);
    } catch (e) {
      console.error("Could not restore SESSION_ID:", e.message);
    }
  }

  const { state, saveCreds } = await useMultiFileAuthState(authDir);
  const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    version,
    logger: pino({ level: "silent" }),
    printQRInTerminal: false,
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, pino({ level: "silent" }))
    },
    browser: ["DIANA V12", "Chrome", "1.0.0"],
    generateHighQualityLinkPreview: false
  });

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", ({ connection, lastDisconnect }) => {
    if (connection === "open") {
      console.log(`🤖 ${BOT_NAME} connected successfully.`);
    }
    if (connection === "close") {
      const code = lastDisconnect?.error?.output?.statusCode;
      const shouldReconnect = code !== DisconnectReason.loggedOut;
      console.log("Connection closed. Reconnect:", shouldReconnect);
      if (shouldReconnect) setTimeout(() => startBot().catch(console.error), 5000);
    }
  });

  sock.ev.on("messages.upsert", async ({ messages }) => {
    const m = messages[0];
    if (!m?.message || m.key.fromMe) return;

    const jid = m.key.remoteJid;
    const text =
      m.message.conversation ||
      m.message.extendedTextMessage?.text ||
      m.message.imageMessage?.caption ||
      m.message.videoMessage?.caption ||
      "";

    if (!text.startsWith(PREFIX)) return;

    const [raw, ...args] = text.slice(PREFIX.length).trim().split(/\s+/);
    const cmd = raw.toLowerCase();

    const reply = t => sock.sendMessage(jid, { text: t }, { quoted: m });

    if (cmd === "ping") {
      const started = Date.now();
      await reply(`🏓 Pong!\n⚡ ${Date.now() - started} ms`);
      return;
    }

    if (cmd === "alive") {
      await reply(`🤖 *${BOT_NAME}*\n\n✅ Online\n📌 Prefix: ${PREFIX}\n👤 Owner: ${OWNER || "Not set"}`);
      return;
    }

    if (cmd === "owner") {
      await reply(`👑 Owner: ${OWNER ? "+" + OWNER : "Not configured"}`);
      return;
    }

    if (cmd === "menu" || cmd === "help") {
      await reply(
`┏▣ ◈ *${BOT_NAME} 🤖* ◈
┃ *ᴏᴡɴᴇʀ* : 📎😭💕Promzy 📎😭💕
┃ *ᴘʀᴇғɪx* : [ ${PREFIX} ]
┃ *ʜᴏsᴛ* : Render
┃ *ᴍᴏᴅᴇ* : ${process.env.MODE || "Private"}
┃ *ᴠᴇʀsɪᴏɴ* : 1.8.4
┗▣

*BASIC MENU*
• ${PREFIX}ping
• ${PREFIX}alive
• ${PREFIX}owner
• ${PREFIX}menu

More DIANA V12 commands can be added to this handler.`
      );
      return;
    }

    if (cmd === "say") {
      if (!args.length) return reply(`Usage: ${PREFIX}say hello`);
      await reply(args.join(" "));
      return;
    }

    await reply(`❌ Unknown command: ${PREFIX}${cmd}\nType ${PREFIX}menu`);
  });
}

module.exports = { startBot };
