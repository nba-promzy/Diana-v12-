require("dotenv").config();
const { startBot } = require("./bot");
startBot().catch(err => {
  console.error("DIANA V12 failed to start:", err);
  process.exit(1);
});
