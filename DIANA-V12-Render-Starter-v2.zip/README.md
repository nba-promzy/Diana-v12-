# DIANA V12 - Render Starter

This project contains:
- `pairing/` = separate pairing website
- `index.js` + `bot.js` = WhatsApp bot
- Render can host the pairing website as a Web Service and the bot as a Background Worker.

## Deploy bot on Render

1. Put this project in GitHub.
2. Create a Render Background Worker from the repository.
3. Build command: `npm install`
4. Start command: `npm start`
5. Add environment variables:
   - `SESSION_ID`
   - `OWNER_NUMBER`
   - `PREFIX`
   - `BOT_NAME`
   - `MODE`
6. Attach a persistent disk and set `AUTH_DIR` to its mount path, e.g. `/opt/render/project/src/auth`.

Render's filesystem is ephemeral unless a persistent disk is attached.

## Deploy pairing website

Create a second Render Web Service from the same repository.

Build command:
`npm install`

Start command:
`node pairing/server.js`

The pairing service must have access to the same dependency installation. It uses Render's `PORT` environment variable automatically.

## Security

Never commit `.env` or a real `SESSION_ID`.
Generate a fresh session if a session credential is exposed.

## Important

This is a clean starter architecture, not a copy of Cypher X source code. The pairing server exports the complete Baileys multi-file auth directory into SESSION_ID. The large command menu can be added module-by-module.
