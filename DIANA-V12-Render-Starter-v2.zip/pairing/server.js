require("dotenv").config();
const express = require("express");
const pino = require("pino");
const fs = require("fs");
const path = require("path");
const {
  default: makeWASocket,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  BufferJSON
} = require("@whiskeysockets/baileys");

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

let sessions = new Map();

function encodeSessionFiles(authDir) {
  const files = {};
  for (const name of fs.readdirSync(authDir)) {
    const full = path.join(authDir, name);
    if (fs.statSync(full).isFile()) {
      files[name] = fs.readFileSync(full, "utf8");
    }
  }
  const payload = JSON.stringify({ files });
  return "DIANA-X:" + Buffer.from(payload).toString("base64");
}

async function createPairing(phone) {
  const clean = phone.replace(/\D/g, "");
  if (!clean || clean.length < 8) throw new Error("Enter a valid WhatsApp number with country code.");

  const id = "pair_" + Date.now();
  const authDir = path.join(process.cwd(), "pairing", "tmp", id);
  fs.mkdirSync(authDir, { recursive: true });

  const { state, saveCreds } = await useMultiFileAuthState(authDir);
  const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    version,
    logger: pino({ level: "silent" }),
    printQRInTerminal: false,
    auth: state,
    browser: ["DIANA V12 Pairing", "Chrome", "1.0.0"]
  });

  sock.ev.on("creds.update", saveCreds);

  const result = { id, code: null, session: null, connected: false, error: null };

  try {
    result.code = await sock.requestPairingCode(clean);
  } catch (e) {
    result.error = e.message;
  }

  sessions.set(id, { sock, state, result, authDir });

  sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
    if (connection === "open") {
      result.connected = true;
      try {
        // Package every Baileys auth file so the bot can restore the
        // complete multi-file auth state from SESSION_ID.
        result.session = encodeSessionFiles(authDir);
      } catch (e) {
        result.error = "Connected, but session export failed: " + e.message;
      }
    }

    if (connection === "close") {
      const code = lastDisconnect?.error?.output?.statusCode;
      if (code) result.error = `Connection closed (${code})`;
    }
  });

  return result;
}

app.post("/api/pair", async (req, res) => {
  try {
    const result = await createPairing(String(req.body.phone || ""));
    res.json({ ok: true, id: result.id, code: result.code });
  } catch (e) {
    res.status(400).json({ ok: false, error: e.message });
  }
});

app.get("/api/session/:id", (req, res) => {
  const item = sessions.get(req.params.id);
  if (!item) return res.status(404).json({ ok: false, error: "Pairing session not found." });

  res.json({
    ok: true,
    connected: item.result.connected,
    session: item.result.session,
    error: item.result.error
  });
});

const port = process.env.PORT || 10000;
app.listen(port, "0.0.0.0", () => {
  console.log(`DIANA pairing server listening on ${port}`);
});
